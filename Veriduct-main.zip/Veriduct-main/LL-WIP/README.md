This is an early-stage, uncompiled prototype of the Veriduct core logic in C. It’s published now to document origin and invite testing. A verified working version will follow shortly.
